#include "Villiage.h"
#include "person.h"


void Villiage::add(Person* person)
{

}

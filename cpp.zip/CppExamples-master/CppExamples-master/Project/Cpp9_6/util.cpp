int pow2(int = 2, int = 3);


int foo()
{
    return pow2() + pow2(3);
}
#include <iostream>

using std::cout;
using std::endl;

int main()
{

}
// output iterator
// *iter = value
// cout

// input iterator
// value = *iter
// cin

// forward iterator
// - forward_list, unordered xxx
// ++ ���� �ۿ� �� ��

// bidirectional iterator
// - list, set, map, multiset, multimap
// ++, --

// random access iterator
// - array, vector, deque
// ++, --, +, -


// continguous access iterator (C++20)
// - array, vector
// ++, --, +, -, physical memory contiguous

#include <iostream>
#include "Player0.h"
#include "Player1.h"
#include "Player2.h"
#include "Player3.h"
#include "Player4.h"
#include "Player5.h"


using namespace std;


int main()
{
    player0();
    player1();
    player2();
    player3();
    player4();
    player5();
}
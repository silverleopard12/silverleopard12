#include <iostream>
#include <vector>
#include "swap.h"


using std::cout;
using std::endl;


int main()
{
    int x = 10, y = 20;
    swap(x, y); // �Ͻ��� ��üȭ
}
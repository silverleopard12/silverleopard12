#include <iostream>
#include "Person.h"
#include "Transaction.h"

using namespace std;

int main()
{
    personFunc();
    buildTransaction();
}
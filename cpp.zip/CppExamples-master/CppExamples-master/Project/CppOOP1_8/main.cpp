#include <iostream>
#include "auto_static.h"
#include "Person.h"

using namespace std;

int main()
{
    autoStatic();
    personFunc();

    
}
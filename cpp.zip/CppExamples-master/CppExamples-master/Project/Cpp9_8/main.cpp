#include <iostream>
#include "functionpointer.h"
#include "callback.h"
#include "character.h"
#include "type.h"

using namespace std;


int main()
{
    functionPointer();
    callback();
    playCharacter();
    type();
}

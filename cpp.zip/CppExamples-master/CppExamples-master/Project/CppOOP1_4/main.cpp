#include <iostream>
#include "Player.h"
#include "String.h"

using namespace std;

int main()
{
    player();
    stringFunc();
}
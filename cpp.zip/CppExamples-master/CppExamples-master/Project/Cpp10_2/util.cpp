extern int x;
int y = 10;

int getX()
{
    return x;
}


int getY()
{
    return y;
}